# Flutter Fifths clock
This clock is for the flutter competition. 
The idea is to represent the circle of fifths and fourth. 
The outer circle completes a cicle every 12 hours, and the inner circle completes a cicle every 1 hour.
So you can tell what time it is by combining the notes. 